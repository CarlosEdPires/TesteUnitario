package br.com.aula;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

import br.com.aula.exception.ContaJaExistenteException;
import br.com.aula.exception.ContaNaoExistenteException;
import br.com.aula.exception.ContaSemSaldoException;
import br.com.aula.exception.NumeroDeContaInvalidoException;
import br.com.aula.exception.ValorInvalidoException;

public class BancoTest {

	@Test
	public void deveCadastrarConta() throws ContaJaExistenteException, NumeroDeContaInvalidoException {

		// Cenario
		Cliente cliente = new Cliente("Joao");
		Conta conta = new Conta(cliente, 123, 0, TipoConta.CORRENTE);
		Banco banco = new Banco();

		// Acao
		banco.cadastrarConta(conta);

		// Verificacao
		assertEquals(1, banco.obterContas().size());
	}

	@Test(expected = ContaJaExistenteException.class)
	public void naoDeveCadastrarContaNumeroRepetido() throws ContaJaExistenteException, NumeroDeContaInvalidoException {

		// Cenario
		Cliente cliente = new Cliente("Joao");
		Conta conta1 = new Conta(cliente, 123, 0, TipoConta.CORRENTE);

		Cliente cliente2 = new Cliente("Maria");
		Conta conta2 = new Conta(cliente2, 123, 0, TipoConta.POUPANCA);

		Banco banco = new Banco();

		// Acao
		banco.cadastrarConta(conta1);
		banco.cadastrarConta(conta2);

		Assert.fail();
	}

	@Test
	public void deveEfetuarTransferenciaContasCorrentes() throws ContaSemSaldoException, ContaNaoExistenteException, ValorInvalidoException {

		// Cenario
		Cliente cliente = new Cliente("Joao");
		Conta contaOrigem = new Conta(cliente, 123, 0, TipoConta.CORRENTE);

		Cliente cliente2 = new Cliente("Maria");
		Conta contaDestino = new Conta(cliente2, 456, 0, TipoConta.CORRENTE);

		Banco banco = new Banco(Arrays.asList(contaOrigem, contaDestino));

		// Acao
		banco.efetuarTransferencia(123, 456, 100);

		// Verificacao
		assertEquals(-100, contaOrigem.getSaldo());
		assertEquals(100, contaDestino.getSaldo());
	}
	
	@Test
	public void naodeveCadastrarComNumeroDeContaInvalido() throws ContaJaExistenteException, NumeroDeContaInvalidoException {

		// Cenario
		Cliente cliente = new Cliente("Joao");
		Conta conta = new Conta(cliente, 100, 0, TipoConta.CORRENTE);
		Banco banco = new Banco();

		// Acao
		banco.cadastrarConta(conta);

		// Verificacao
		assertTrue(conta.getNumeroConta() > 0);
	}
	
	@Test(expected = ContaJaExistenteException.class)
	public void naodeveCadastrarComNomeExistente() throws ContaJaExistenteException, NumeroDeContaInvalidoException {

		// Cenario
		Cliente cliente = new Cliente("Joao");
		Conta conta = new Conta(cliente, 123, 0, TipoConta.CORRENTE);

		Conta conta2 = new Conta(cliente, 124, 0, TipoConta.CORRENTE);
		
		Banco banco = new Banco(Arrays.asList(conta));
		
		// Acao
		banco.cadastrarConta(conta2);

		// Verificacao
		
	}
	
	@Test
	public void naodeveTransferirValorNegativo() throws ContaSemSaldoException, ContaNaoExistenteException, ValorInvalidoException {

		// Cenario
		Cliente cliente = new Cliente("Joao");
		Conta contaOrigem = new Conta(cliente, 123, 0, TipoConta.CORRENTE);

		Cliente cliente2 = new Cliente("Maria");
		Conta contaDestino = new Conta(cliente2, 456, 0, TipoConta.CORRENTE);

		Banco banco = new Banco(Arrays.asList(contaOrigem, contaDestino));

		// Acao
		banco.efetuarTransferencia(123, 456, 100);

		// Verificacao
		
	}
	
	@Test
	public void deveVerificarExistenciadeDestino() throws ContaSemSaldoException, ContaNaoExistenteException, ValorInvalidoException {

		// Cenario
		Cliente cliente = new Cliente("Joao");
		Conta contaOrigem = new Conta(cliente, 123, 0, TipoConta.CORRENTE);

		Cliente cliente2 = new Cliente("Maria");
		Conta contaDestino = new Conta(cliente2, 456, 0, TipoConta.CORRENTE);

		Banco banco = new Banco(Arrays.asList(contaOrigem, contaDestino));

		// Acao
		banco.efetuarTransferencia(123, 456, 100);

		// Verificacao
		
	}
	
	
}
