package br.com.aula.exception;

public class ContaSemSaldoException extends Exception {

	private static final long serialVersionUID = 1L;

}
